
import telebot
from flask import Flask, request
import os

API_TOKEN = os.getenv("BOT_API_TOKEN")

bot = telebot.TeleBot(API_TOKEN)
app = Flask(__name__)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "سلام! من ربات بی‌حد هستم، بدون محدودیت و آماده به خدمت!")

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, f"پیام شما: {message.text}")

@app.route('/', methods=['POST'])
def webhook():
    if request.headers.get('content-type') == 'application/json':
        json_string = request.get_data().decode('utf-8')
        update = telebot.types.Update.de_json(json_string)
        bot.process_new_updates([update])
        return '', 200
    else:
        return '', 403

if __name__ == "__main__":
    bot.remove_webhook()
    bot.set_webhook(url=os.getenv("WEBHOOK_URL"))
    app.run(host="0.0.0.0", port=int(os.environ.get('PORT', 5000)))
